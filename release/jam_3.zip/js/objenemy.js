"use strict";

class ObjEnemy extends ObjCharacter
{
	constructor()
	{
		super();
	}
}

class ObjEnemyFirst extends ObjEnemy
{
}
