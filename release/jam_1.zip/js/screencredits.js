"use strict";

class ScreenMenu extends Screen2
{
	constructor()
	{
		super();
	}
	
	init()
	{
	}
}
